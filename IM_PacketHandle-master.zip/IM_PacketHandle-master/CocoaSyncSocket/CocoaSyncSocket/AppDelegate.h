//
//  AppDelegate.h
//  CocoaSyncSocket
//
//  Created by 涂耀辉 on 16/12/26.
//  Copyright © 2016年 涂耀辉. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

