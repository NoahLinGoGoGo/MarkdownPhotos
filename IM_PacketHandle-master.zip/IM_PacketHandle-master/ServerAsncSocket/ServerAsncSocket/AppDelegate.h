//
//  AppDelegate.h
//  ServerAsncSocket
//
//  Created by 涂耀辉 on 17/1/19.
//  Copyright © 2017年 涂耀辉. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

